import setuptools

setuptools.setup(
    name = "quick-sqlite-database",
    version = "0.0.1",
    author = "Dada878",
    description = ("A lightweight key-value database basic sqlite"),
    packages=['quick_sqlite'],
)